
from flask import Flask, jsonify, request, send_from_directory
from pathlib import Path
import json
import sys

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))

from recommendation_engine import build_weekly_plan, load_exercises

app = Flask(__name__, static_folder=".", static_url_path="")

EXERCISES = load_exercises()


@app.get("/")
def home():
    return send_from_directory(BASE, "index.html")


@app.get("/api/exercises")
def exercises():
    items = []
    for exercise_id, item in EXERCISES.items():
        items.append({
            "id": exercise_id,
            **item
        })
    return jsonify({
        "count": len(items),
        "exercises": items
    })


@app.get("/api/exercise/<exercise_id>")
def exercise(exercise_id):
    item = EXERCISES.get(exercise_id)
    if not item:
        return jsonify({"error": "Exercise not found"}), 404
    return jsonify({
        "id": exercise_id,
        **item
    })


@app.post("/api/recommend")
def recommend():
    profile = request.get_json(silent=True) or {}

    # Safe defaults for the first version.
    profile.setdefault("goal", "general fitness")
    profile.setdefault("experience", "beginner")
    profile.setdefault("days_per_week", 3)
    profile.setdefault("exercises_per_day", 6)
    profile.setdefault("equipment", ["Bodyweight"])
    profile.setdefault("target_muscles", [])

    try:
        profile["days_per_week"] = int(profile["days_per_week"])
        profile["exercises_per_day"] = int(profile["exercises_per_day"])
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid days or exercise count"}), 400

    plan = build_weekly_plan(profile)
    return jsonify(plan)


@app.get("/health")
def health():
    return jsonify({
        "status": "ok",
        "service": "FORMFIT AI",
        "exercise_count": len(EXERCISES)
    })


if __name__ == "__main__":
    print("FORMFIT AI web server")
    print("Open: http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=True)
