
let exercises = [];
let currentExercise = null;
let cameraStream = null;

let poseTimer = null;
let frameCanvas = null;
let poseBusy = false;
let requestSerial = 0;

// ------------------------------------------------------------
// SMOOTH PIPE STATE
// ------------------------------------------------------------
// The Python engine remains responsible for form decisions.
// These values only smooth what the user sees on screen.
const visual = {
  pipes: [],
  targets: [],
  score: 0,
  reps: 0,
  status: "yellow",
  message: "",
  lastTime: performance.now(),
  frameId: 0
};

const state = {
  goal: "muscle gain",
  equipment: ["Bodyweight"]
};

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

function showView(name) {
  $$(".view").forEach(v =>
    v.classList.remove("active-view")
  );

  const target = $(`#${name}View`);
  if (target) target.classList.add("active-view");

  $$(".nav-item").forEach(b =>
    b.classList.toggle(
      "active",
      b.dataset.view === name
    )
  );

  const titles = {
    home: "Train with better form.",
    recommend: "Build your workout.",
    library: "Choose your movement.",
    form: "Practice with better form."
  };

  $("#pageTitle").textContent =
    titles[name] || "FORMFIT AI";
}

function bindNavigation() {
  $$("[data-view]").forEach(btn => {
    btn.addEventListener("click", () =>
      showView(btn.dataset.view)
    );
  });

  $("#quickAI").onclick = () =>
    showView("recommend");

  $("#quickLibrary").onclick = () =>
    showView("library");
}

async function loadExercises() {
  const res = await fetch("/api/exercises");
  const data = await res.json();

  exercises = data.exercises || [];

  $("#exerciseCount").textContent =
    exercises.length;

  const categories = [
    ...new Set(
      exercises.map(x => x.category)
    )
  ].sort();

  $("#categoryFilter").innerHTML =
    `<option value="">All categories</option>` +
    categories.map(
      c => `<option>${escapeHtml(c)}</option>`
    ).join("");

  renderExercises();
}

function renderExercises() {
  const query =
    ($("#searchInput").value || "")
      .toLowerCase();

  const category =
    $("#categoryFilter").value;

  const filtered = exercises.filter(ex => {
    const text =
      ex.name.toLowerCase() +
      " " +
      (ex.primary_muscles || [])
        .join(" ")
        .toLowerCase();

    return (
      text.includes(query) &&
      (!category || ex.category === category)
    );
  });

  $("#exerciseGrid").innerHTML =
    filtered.map(ex => {
      const status =
        ex.form_check_status || "COMING_SOON";

      const cls =
        status === "READY"
          ? "ready"
          : status === "BASIC"
            ? "basic"
            : "coming";

      const statusText =
        status === "READY"
          ? "AI FORM READY"
          : status === "BASIC"
            ? "BASIC CHECK"
            : "LIBRARY";

      return `
        <article
          class="exercise-card"
          data-id="${escapeHtml(ex.id)}"
        >
          <div class="exercise-top">
            <span class="tiny-label">
              ${escapeHtml(ex.category)}
            </span>
            <span class="${cls} tiny-label">
              ${statusText}
            </span>
          </div>

          <h4>${escapeHtml(ex.name)}</h4>

          <p>
            ${escapeHtml(
              (ex.primary_muscles || [])
                .join(" • ")
            )}
          </p>

          ${(ex.equipment || [])
            .slice(0, 3)
            .map(
              e =>
                `<span class="tag">
                  ${escapeHtml(e)}
                </span>`
            )
            .join("")}
        </article>
      `;
    })
    .join("");

  $$(".exercise-card").forEach(card => {
    card.onclick = () =>
      selectExercise(card.dataset.id);
  });
}

function resetVisualState() {
  visual.pipes = [];
  visual.targets = [];
  visual.score = 0;
  visual.reps = 0;
  visual.status = "yellow";
  visual.message = "";
  visual.frameId++;
  drawClearOverlay();
}

async function selectExercise(id) {
  const ex =
    exercises.find(x => x.id === id);

  if (!ex) return;

  currentExercise = ex;
  resetVisualState();

  $("#selectedExerciseTitle")
    .textContent = ex.name;

  $("#selectedExerciseMeta")
    .textContent =
      `${ex.category} • ${ex.difficulty} • ` +
      `${(ex.primary_muscles || []).join(", ")} • ` +
      `${ex.form_check_status}`;

  if (ex.form_check_status !== "READY") {
    setCoachStatus(
      "LIBRARY MODE — FORM RULE NOT READY",
      "var(--muted)"
    );
    showView("form");
    return;
  }

  try {
    const response = await fetch(
      "http://127.0.0.1:5050/api/session",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          exercise: ex.id
        })
      }
    );

    if (!response.ok) {
      throw new Error("Pose API unavailable");
    }

    setCoachStatus(
      "AI FORM CHECK READY",
      "var(--accent)"
    );

  } catch {
    setCoachStatus(
      "START POSE API FIRST",
      "var(--red)"
    );
  }

  showView("form");
}

function setCoachStatus(text, color) {
  const status = $("#coachStatus");

  status.textContent = text;
  status.style.color = color;
}

function ensureOverlay() {
  const wrap = $("#cameraArea");

  if (!wrap) return null;

  let canvas = $("#poseOverlay");

  if (!canvas) {
    canvas = document.createElement("canvas");
    canvas.id = "poseOverlay";

    canvas.style.position = "absolute";
    canvas.style.inset = "0";
    canvas.style.width = "100%";
    canvas.style.height = "100%";
    canvas.style.pointerEvents = "none";
    canvas.style.zIndex = "3";

    wrap.appendChild(canvas);
  }

  return canvas;
}

function resizeOverlay() {
  const video = $("#cameraVideo");
  const canvas = ensureOverlay();

  if (
    !video ||
    !canvas ||
    !video.videoWidth ||
    !video.videoHeight
  ) {
    return;
  }

  if (
    canvas.width !== video.videoWidth ||
    canvas.height !== video.videoHeight
  ) {
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
  }
}

function drawClearOverlay() {
  const canvas = $("#poseOverlay");

  if (!canvas) return;

  const ctx = canvas.getContext("2d");

  ctx.clearRect(
    0,
    0,
    canvas.width,
    canvas.height
  );
}

function pointToCanvas(point, canvas) {
  return {
    x: point.x * canvas.width,
    y: point.y * canvas.height
  };
}

function smoothNumber(oldValue, newValue, factor) {
  return oldValue +
    (newValue - oldValue) * factor;
}

function smoothPoint(oldPoint, newPoint, factor) {
  if (!oldPoint) {
    return {
      x: newPoint.x,
      y: newPoint.y
    };
  }

  const dx = newPoint.x - oldPoint.x;
  const dy = newPoint.y - oldPoint.y;
  const distance = Math.sqrt(dx * dx + dy * dy);

  // Large movement = follow almost immediately.
  // Small movement = retain enough smoothing to remove jitter.
  let adaptive = factor;

  if (distance > 0.055) {
    adaptive = 0.985;
  } else if (distance > 0.025) {
    adaptive = 0.94;
  } else {
    adaptive = 0.84;
  }

  return {
    x: smoothNumber(
      oldPoint.x,
      newPoint.x,
      adaptive
    ),
    y: smoothNumber(
      oldPoint.y,
      newPoint.y,
      adaptive
    )
  };
}

function smoothPipes(newPipes) {
  // V5: high responsiveness. The adaptive smoothPoint()
  // handles jitter without making the pipe trail behind the body.
  const factor = 0.92;

  if (!visual.pipes.length) {
    visual.pipes = newPipes.map(pipe => ({
      a: {...pipe.a},
      b: {...pipe.b},
      status: pipe.status
    }));

    return;
  }

  const result = [];

  for (let i = 0; i < newPipes.length; i++) {
    const next = newPipes[i];
    const old = visual.pipes[i];

    if (!old) {
      result.push({
        a: {...next.a},
        b: {...next.b},
        status: next.status
      });
      continue;
    }

    result.push({
      a: smoothPoint(
        old.a,
        next.a,
        factor
      ),
      b: smoothPoint(
        old.b,
        next.b,
        factor
      ),
      status: next.status
    });
  }

  visual.pipes = result;
}

function smoothTargets(newTargets) {
  // Yellow target should follow corrections quickly.
  const factor = 0.94;

  if (!visual.targets.length) {
    visual.targets =
      newTargets.map(target => ({
        actual: {...target.actual},
        desired: {...target.desired},
        label: target.label
      }));

    return;
  }

  visual.targets =
    newTargets.map((next, i) => {
      const old = visual.targets[i];

      if (!old) {
        return {
          actual: {...next.actual},
          desired: {...next.desired},
          label: next.label
        };
      }

      return {
        actual: smoothPoint(
          old.actual,
          next.actual,
          factor
        ),
        desired: smoothPoint(
          old.desired,
          next.desired,
          factor
        ),
        label: next.label
      };
    });
}

function drawPoseResult(data) {
  const canvas = ensureOverlay();

  if (!canvas) return;

  resizeOverlay();

  smoothPipes(data.pipes || []);
  smoothTargets(data.targets || []);

  visual.score = data.score ?? visual.score;
  visual.reps = data.reps ?? visual.reps;
  visual.status = data.status || visual.status;
  visual.message = data.message || "";

  // IMPORTANT:
  // Rendering happens continuously with requestAnimationFrame,
  // while API frames arrive more slowly.
  // This makes the pipes visually smooth instead of jumping.
}

function renderSmoothOverlay() {
  const canvas = ensureOverlay();

  if (!canvas) {
    requestAnimationFrame(
      renderSmoothOverlay
    );
    return;
  }

  resizeOverlay();

  const ctx = canvas.getContext("2d");

  ctx.clearRect(
    0,
    0,
    canvas.width,
    canvas.height
  );

  // ----------------------------------------------------------
  // SMOOTH GREEN / RED / YELLOW PIPES
  // ----------------------------------------------------------
  for (const pipe of visual.pipes) {
    const a =
      pointToCanvas(pipe.a, canvas);

    const b =
      pointToCanvas(pipe.b, canvas);

    const color =
      pipe.status === "green"
        ? "#20e070"
        : pipe.status === "yellow"
          ? "#f4d35e"
          : "#ff4d5d";

    ctx.beginPath();

    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);

    ctx.strokeStyle = color;
    ctx.lineWidth = 5;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    ctx.shadowBlur = 7;
    ctx.shadowColor = color;

    ctx.stroke();

    ctx.shadowBlur = 0;
  }

  // ----------------------------------------------------------
  // YELLOW DOTTED CORRECTION GUIDE
  // ----------------------------------------------------------
  for (const target of visual.targets) {
    const actual =
      pointToCanvas(
        target.actual,
        canvas
      );

    const desired =
      pointToCanvas(
        target.desired,
        canvas
      );

    ctx.beginPath();

    ctx.setLineDash([
      6,
      8
    ]);

    ctx.moveTo(
      actual.x,
      actual.y
    );

    ctx.lineTo(
      desired.x,
      desired.y
    );

    ctx.strokeStyle =
      "#f4d35e";

    ctx.lineWidth = 2.5;

    ctx.stroke();

    ctx.setLineDash([]);

    ctx.beginPath();

    ctx.arc(
      desired.x,
      desired.y,
      7,
      0,
      Math.PI * 2
    );

    ctx.fillStyle =
      "#f4d35e";

    ctx.fill();

    ctx.font =
      "bold 13px Inter";

    ctx.fillStyle =
      "#f4d35e";

    ctx.fillText(
      target.label,
      desired.x + 11,
      desired.y - 8
    );
  }

  requestAnimationFrame(
    renderSmoothOverlay
  );
}

function updateFormUI(data) {
  const statusText =
    data.status === "green"
      ? "✓ CORRECT FORM"
      : data.status === "red"
        ? "✕ FIX YOUR FORM"
        : "→ ADJUST POSITION";

  const statusColor =
    data.status === "green"
      ? "var(--accent)"
      : data.status === "red"
        ? "var(--red)"
        : "var(--yellow)";

  setCoachStatus(
    `${statusText} • ${data.score}% • REPS ${data.reps}`,
    statusColor
  );

  const meta =
    $("#selectedExerciseMeta");

  if (meta) {
    meta.textContent =
      `${data.message} • ` +
      `View: ${data.view} • ` +
      `Score: ${data.score}% • ` +
      `Reps: ${data.reps}`;
  }

  const panel =
    $(".coach-panel");

  if (
    panel &&
    currentExercise
  ) {
    const cues =
      currentExercise.coaching || [];

    panel
      .querySelectorAll(
        ".dynamic-cue"
      )
      .forEach(x => x.remove());

    cues
      .slice(0, 3)
      .forEach(cue => {
        const row =
          document.createElement("div");

        row.className =
          "coach-cue dynamic-cue";

        row.innerHTML =
          `● <span>${escapeHtml(cue)}</span>`;

        panel.insertBefore(
          row,
          $("#backLibrary")
        );
      });
  }
}

async function sendFrameToPoseAPI() {
  if (poseBusy) return;

  const video = $("#cameraVideo");

  if (
    !video ||
    !video.videoWidth ||
    !video.videoHeight ||
    !cameraStream ||
    !currentExercise ||
    currentExercise.form_check_status !== "READY"
  ) {
    return;
  }

  if (!frameCanvas) {
    frameCanvas = document.createElement("canvas");
  }

  // Smaller upload = less encode/decode + less CPU.
  const width = 360;
  const height = Math.round(
    width * video.videoHeight / video.videoWidth
  );

  frameCanvas.width = width;
  frameCanvas.height = height;

  const ctx = frameCanvas.getContext(
    "2d",
    { alpha: false }
  );

  ctx.drawImage(
    video,
    0,
    0,
    width,
    height
  );

  poseBusy = true;

  try {
    const blob = await new Promise(resolve =>
      frameCanvas.toBlob(
        resolve,
        "image/jpeg",
        0.52
      )
    );

    if (!blob) {
      throw new Error("JPEG encode failed");
    }

    const response = await fetch(
      `http://127.0.0.1:5050/api/analyze?exercise=${encodeURIComponent(currentExercise.id)}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "image/jpeg"
        },
        body: blob,
        cache: "no-store"
      }
    );

    if (!response.ok) {
      throw new Error("Pose API error");
    }

    const data = await response.json();

    if (data.detected) {
      drawPoseResult(data);
      updateFormUI(data);
    } else {
      visual.pipes = [];
      visual.targets = [];

      setCoachStatus(
        "BODY NOT DETECTED",
        "var(--red)"
      );
    }

  } catch {
    setCoachStatus(
      "POSE API NOT RUNNING",
      "var(--red)"
    );
  } finally {
    poseBusy = false;
  }
}
function startPoseLoop() {
  stopPoseLoop();

  // Target up to ~12 FPS. poseBusy prevents backlog.
  poseTimer =
    setInterval(
      sendFrameToPoseAPI,
      83
    );
}

function stopPoseLoop() {
  if (poseTimer) {
    clearInterval(
      poseTimer
    );

    poseTimer = null;
  }
}

async function enableCamera() {
  try {
    cameraStream =
      await navigator.mediaDevices
        .getUserMedia({
          video: {
            facingMode: "user",
            width: {
              ideal: 1280
            },
            height: {
              ideal: 720
            }
          },
          audio: false
        });

    const video =
      $("#cameraVideo");

    video.srcObject =
      cameraStream;

    video.style.display =
      "block";

    video.style.transform =
      "scaleX(-1)";

    await video.play();

    ensureOverlay();
    resizeOverlay();

    $("#cameraArea .camera-icon")
      .style.display = "none";

    $("#cameraArea h3")
      .style.display = "none";

    $("#cameraArea p")
      .style.display = "none";

    $("#cameraBtn")
      .style.display = "none";

    startPoseLoop();

  } catch {
    alert(
      "Camera permission was not available."
    );
  }
}

function bindFormChoices() {
  $$(".choice[data-field='goal']")
    .forEach(btn => {
      btn.onclick = () => {
        state.goal =
          btn.dataset.value;

        $$(".choice[data-field='goal']")
          .forEach(
            b =>
              b.classList.remove(
                "selected"
              )
          );

        btn.classList.add(
          "selected"
        );
      };
    });

  $$("#equipmentChoices .choice")
    .forEach(btn => {
      btn.onclick = () => {
        const value =
          btn.dataset.value;

        if (
          state.equipment
            .includes(value)
        ) {
          if (
            state.equipment.length > 1
          ) {
            state.equipment =
              state.equipment.filter(
                x => x !== value
              );

            btn.classList.remove(
              "selected"
            );
          }
        } else {
          state.equipment.push(
            value
          );

          btn.classList.add(
            "selected"
          );
        }
      };
    });

  $("#recommendForm")
    .addEventListener(
      "submit",
      generatePlan
    );
}

async function generatePlan(event) {
  event.preventDefault();

  const profile = {
    goal: state.goal,
    experience:
      $("#experience").value,
    days_per_week:
      Number($("#days").value),
    exercises_per_day:
      Number($("#perDay").value),
    equipment:
      state.equipment,
    target_muscles: []
  };

  const result =
    $("#planResult");

  result.innerHTML =
    `<div class="day-card">
      <strong>Building your plan…</strong>
      <p style="color:var(--muted)">
        Scoring exercises from the library.
      </p>
    </div>`;

  const res =
    await fetch(
      "/api/recommend",
      {
        method: "POST",
        headers: {
          "Content-Type":
            "application/json"
        },
        body:
          JSON.stringify(profile)
      }
    );

  const data =
    await res.json();

  if (!res.ok) {
    result.innerHTML =
      `<div class="day-card">
        <strong>
          Could not build plan.
        </strong>
        <p>
          ${escapeHtml(
            data.error ||
            "Unknown error"
          )}
        </p>
      </div>`;

    return;
  }

  result.innerHTML =
    (data.days || [])
      .map(day => `
        <div class="day-card">
          <h3>
            Day ${day.day} —
            ${escapeHtml(day.name)}
          </h3>

          <small style="color:var(--muted)">
            5 min warm-up
          </small>

          ${(day.exercises || [])
            .map(ex => `
              <div class="plan-ex">
                <div>
                  <strong>
                    ${ex.order}.
                    ${escapeHtml(
                      ex.exercise
                    )}
                  </strong>

                  <small>
                    ${escapeHtml(
                      ex.primary_muscles
                        .join(" • ")
                    )}
                    • ${ex.sets} × ${ex.reps}
                    • ${ex.rest_seconds}s rest
                  </small>
                </div>

                <span class="badge">
                  ${escapeHtml(
                    ex.form_check_status
                  )}
                </span>
              </div>
            `)
            .join("")}
        </div>
      `)
      .join("");
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

document.addEventListener(
  "DOMContentLoaded",
  async () => {
    bindNavigation();
    bindFormChoices();

    $("#searchInput")
      .addEventListener(
        "input",
        renderExercises
      );

    $("#categoryFilter")
      .addEventListener(
        "change",
        renderExercises
      );

    $("#cameraBtn").onclick =
      enableCamera;

    $("#backLibrary").onclick =
      () => showView("library");

    window.addEventListener(
      "resize",
      resizeOverlay
    );

    // Start the independent 60-ish FPS
    // visual renderer once.
    requestAnimationFrame(
      renderSmoothOverlay
    );

    await loadExercises();
  }
);
