
# FORMFIT AI — Integration V2

This version adds a browser-camera -> Python MediaPipe bridge.

## 1. Install

Activate the same virtual environment used by FormFit:

```powershell
.\venv_app\Scripts\activate
pip install -r requirements_pose_api.txt
```

If your existing environment already has Flask/OpenCV/MediaPipe/Numpy,
the install should simply confirm them.

## 2. Start the pose API

Terminal 1:

```powershell
python formfit_api.py
```

Keep it running.

Test:

```text
http://127.0.0.1:5050/api/pose/health
```

You should see JSON with `"mediapipe": true`.

## 3. Start the website

Terminal 2:

```powershell
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

Go to:

Form Checker -> Enable camera.

The status should change to:

PERSON DETECTED • LANDMARKS TRACKING

## Important

This bridge intentionally returns MediaPipe landmarks only.

It does NOT falsely claim that the full existing pose_engine.py has been
converted into a web API, because that depends on the exact public
processing functions/classes in the current local file.

The next integration step is to expose one clean function from
pose_engine.py, for example:

    result = process_frame(frame, exercise)

Then formfit_api.py can call that function and return:

    status
    score
    reps
    message
    landmarks
    correction pipes

without duplicating the form rules.
